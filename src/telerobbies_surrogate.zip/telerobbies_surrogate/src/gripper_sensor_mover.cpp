#include "gripper_sensor_mover.h"

GripperSensorMover::GripperSensorMover( ros::NodeHandle pnh, std::string left_gripper_sensor_topic, std::string right_gripper_sensor_topic ) :
  left_gripper_command_action_client_(left_gripper_sensor_topic + "/gripper_action", true),
  right_gripper_command_action_client_(right_gripper_sensor_topic + "/gripper_action",true),
  left_gripper_contact_client_(left_gripper_sensor_topic + "/find_contact", true),
  right_gripper_contact_client_(right_gripper_sensor_topic + "/find_contact",true),
  left_gripper_force_client_(left_gripper_sensor_topic + "/force_servo", true),
  right_gripper_force_client_(right_gripper_sensor_topic + "/force_servo",true)
{
    std::cout << "Starting gripper sensor mover" << std::endl;

    //wait for the gripper action server to come up 
    while(!left_gripper_command_action_client_.waitForServer(ros::Duration(5.0))){
      ROS_INFO("Waiting for the l_gripper_sensor_controller/gripper_action action server to come up");
    }

    while(!left_gripper_contact_client_.waitForServer(ros::Duration(5.0))){
      ROS_INFO("Waiting for the l_gripper_sensor_controller/find_contact action server to come up");
    }

    while(!left_gripper_force_client_.waitForServer(ros::Duration(5.0))){
      ROS_INFO("Waiting for the l_gripper_sensor_controller/force_servo action server to come up");
    }

    while(!right_gripper_command_action_client_.waitForServer(ros::Duration(5.0))){
      ROS_INFO("Waiting for the r_gripper_sensor_controller/gripper_action action server to come up");
    }

    while(!right_gripper_contact_client_.waitForServer(ros::Duration(5.0))){
      ROS_INFO("Waiting for the r_gripper_sensor_controller/find_contact action server to come up");
    }

    while(!right_gripper_force_client_.waitForServer(ros::Duration(5.0))){
      ROS_INFO("Waiting for the r_gripper_sensor_controller/force_servo action server to come up");
    }

    joy_sub_ = nh_.subscribe<sensor_msgs::Joy>( "joy_left_right_gripper", 1, boost::bind(&GripperSensorMover::joyCb, this, _1) );
    pnh.param<double>( "hold_force", holdForce, 5 );

}

GripperSensorMover::~GripperSensorMover()
{
}


//Open the gripper
void GripperSensorMover::open(int side){
    pr2_controllers_msgs::Pr2GripperCommandGoal open;
    open.command.position = 0.08;
    open.command.max_effort = -1.0;
    if(side == 0){
        ROS_INFO("LEFT : Sending open goal");
        left_gripper_command_action_client_.sendGoal(open);
        //left_gripper_command_action_client_.waitForResult();
        //if(left_gripper_command_action_client_.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
        //  ROS_INFO("LEFT : The left gripper opened!");
        //else
        //  ROS_INFO("LEFT : The left gripper failed to open.");
    }
    else{
        ROS_INFO("RIGHT: Sending open goal");
        right_gripper_command_action_client_.sendGoal(open);
        //right_gripper_command_action_client_.waitForResult();
        //if(right_gripper_command_action_client_.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
        //  ROS_INFO("RIGHT: The right gripper opened!");
        //else
        //  ROS_INFO("RIGHT: The right gripper failed to open.");
    }
}


//Hold somethign with a constant force in the gripper
void GripperSensorMover::hold( int side, double holdForce){
    pr2_gripper_sensor_msgs::PR2GripperForceServoGoal squeeze;
    squeeze.command.fingertip_force = holdForce;   // hold with X N of force
    
    if(side == 0){
        ROS_INFO("LEFT : Sending hold goal");
        left_gripper_force_client_.sendGoal(squeeze);
        //left_gripper_force_client_.waitForResult();
        //if(left_gripper_force_client_.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
        //  ROS_INFO("LEFT : Stable force was achieved");
        //else
        //  ROS_INFO("LEFT : Stable force was NOT achieved");
    }
    else{
        ROS_INFO("RIGHT: Sending hold goal");
        right_gripper_force_client_.sendGoal(squeeze);
        //right_gripper_force_client_.waitForResult();
        //if(right_gripper_force_client_.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
        //  ROS_INFO("RIGHT: Stable force was achieved");
        //else
        //  ROS_INFO("RIGHT: Stable force was NOT achieved");
    }
}


//Find two contacts and go into force control mode
void GripperSensorMover::findTwoContacts(int side){
    pr2_gripper_sensor_msgs::PR2GripperFindContactGoal findTwo;
    findTwo.command.contact_conditions = findTwo.command.BOTH;  // close until both fingers contact
    findTwo.command.zero_fingertip_sensors = true;   // zero fingertip sensor values before moving
    
    if(side == 0){

        ROS_INFO("LEFT : Sending find 2 contact goal");
        left_gripper_contact_client_.sendGoal(findTwo);
        //left_gripper_contact_client_.waitForResult(ros::Duration(5.0));
        //if(left_gripper_contact_client_.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
        //{
        //  ROS_INFO("LEFT : Contact found. Left: %d, Right: %d", left_gripper_contact_client_.getResult()->data.left_fingertip_pad_contact, 
        //       left_gripper_contact_client_.getResult()->data.right_fingertip_pad_contact);
        //  ROS_INFO("LEFT : Contact force. Left: %f, Right: %f", left_gripper_contact_client_.getResult()->data.left_fingertip_pad_force, 
        //       left_gripper_contact_client_.getResult()->data.right_fingertip_pad_force);
        //}
        //else
        //  ROS_INFO("LEFT : The gripper did not find a contact or could not maintain contact force.");
    }
    else{
        ROS_INFO("RIGHT: Sending find 2 contact goal");
        right_gripper_contact_client_.sendGoal(findTwo);
        //right_gripper_contact_client_.waitForResult(ros::Duration(5.0));
        //if(right_gripper_contact_client_.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
        //{
        //  ROS_INFO("RIGHT: Contact found. Left: %d, Right: %d", right_gripper_contact_client_.getResult()->data.left_fingertip_pad_contact, 
        //       right_gripper_contact_client_.getResult()->data.right_fingertip_pad_contact);
        //  ROS_INFO("RIGHT: Contact force. Left: %f, Right: %f", right_gripper_contact_client_.getResult()->data.left_fingertip_pad_force, 
        //       right_gripper_contact_client_.getResult()->data.right_fingertip_pad_force);
        //}
        //else
        //  ROS_INFO("RIGHT: The gripper did not find a contact or could not maintain contact force.");
    }
}

void GripperSensorMover::joyCb(sensor_msgs::JoyConstPtr joy_gripper)
{
  /*
  if ( ros::Time::now() - last_update_time_ < ros::Duration(update_freq_) )
  {
    return;
  }
  */
  /*if ( joy_msg->buttons.size() <= deadman_button_  )
  {
    ROS_ERROR_ONCE("Button index for deadman switch is out of bounds!");
    return;
  }*/

  if(true)// ( joy_msg->buttons.at(deadman_button_) )
  {
    last_update_time_ = ros::Time::now();
    
    // retrieve the point from the pose topic sent in the target frame -> needs to be the same in unity!
    float left_joy_val = joy_gripper->axes.at(0);
    float right_joy_val = joy_gripper->axes.at(1);
    if(left_joy_val > 0.04999){ // if the trigger is pressed, we open
        if(!leftOpen){ // the open bools are there to prevent the robot from being spammed with the commands
            open(0);
            leftOpen = true;
        }
    }
    else{ // if the trigger is let go, we close & hold
        if(leftOpen){
            findTwoContacts(0);
            hold(0, holdForce);
            leftOpen = false;
        }
    }
    if(right_joy_val > 0.04999){
        if(!rightOpen){
            open(1);   
            rightOpen = true;
        }
    }
    else{ // if the trigger is let go, we close & hold
        if(rightOpen){
            findTwoContacts(1);
            hold(1, holdForce);
            rightOpen = false;
        }
    }

  }
}

