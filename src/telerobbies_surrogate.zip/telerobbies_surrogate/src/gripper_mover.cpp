/*********************************************************************
*
*  Copyright (c) 2013, Willow Garage, Inc.
*  All rights reserved.
*
*  Redistribution and use in source and binary forms, with or without
*  modification, are permitted provided that the following conditions
*  are met:
*
*   * Redistributions of source code must retain the above copyright
*     notice, this list of conditions and the following disclaimer.
*   * Redistributions in binary form must reproduce the above
*     copyright notice, this list of conditions and the following
*     disclaimer in the documentation and/or other materials provided
*     with the distribution.
*   * Neither the name of the Willow Garage nor the names of its
*     contributors may be used to endorse or promote products derived
*     from this software without specific prior written permission.
*
*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
*  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
*  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
*  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
*  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
*  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
*  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
*  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
*  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
*  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
*  POSSIBILITY OF SUCH DAMAGE.
*********************************************************************/


#include "gripper_mover.h"

GripperMover::GripperMover( ros::NodeHandle pnh, std::string left_gripper_action_topic, std::string right_gripper_action_topic ) :
  left_gripper_command_action_client_(left_gripper_action_topic, true),
  right_gripper_command_action_client_(right_gripper_action_topic,true)
{
  std::cout << "Starting gripper mover" << std::endl;
  joy_sub_ = nh_.subscribe<sensor_msgs::Joy>( "joy_left_right_gripper", 1, boost::bind(&GripperMover::joyCb, this, _1) );

  pnh.param<int>( "deadman_button", deadman_button_, 0 );

  pnh.param<double>( "update_freq", update_freq_, 0.1 );
}

GripperMover::~GripperMover()
{
}

void GripperMover::joyCb(sensor_msgs::JoyConstPtr joy_gripper)
{
  /*
  if ( ros::Time::now() - last_update_time_ < ros::Duration(update_freq_) )
  {
    return;
  }
  */
  /*if ( joy_msg->buttons.size() <= deadman_button_  )
  {
    ROS_ERROR_ONCE("Button index for deadman switch is out of bounds!");
    return;
  }*/

  if(true)// ( joy_msg->buttons.at(deadman_button_) )
  {
    last_update_time_ = ros::Time::now();
    
    // retrieve the point from the pose topic sent in the target frame -> needs to be the same in unity!

    left_gripper_goal_.command.max_effort = -1;
    left_gripper_goal_.command.position = joy_gripper->axes.at(0);
    right_gripper_goal_.command.max_effort = -1;
    right_gripper_goal_.command.position = joy_gripper->axes.at(1);
    left_gripper_command_action_client_.sendGoal( left_gripper_goal_ );
    right_gripper_command_action_client_.sendGoal(right_gripper_goal_);
    //ros::Duration waitTimeout = ros::Duration(2);
    //point_head_action_client_.waitForResult(waitTimeout);
  }
}
