^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pr2_surrogate
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.6 (2015-02-11)
------------------

0.0.5 (2014-09-18)
------------------
* Changed maintainer; updated websites
* Contributors: TheDash

0.0.4 (2014-09-07)
------------------
* Replaced dependency on rviz plugins
* Contributors: TheDash

0.0.3 (2014-09-07)
------------------
* added audio param etc. to desktop/robot.launch
* updated README
* check return code of dynparam call, removed signed/unsigned warning
* Contributors: David Gossow
