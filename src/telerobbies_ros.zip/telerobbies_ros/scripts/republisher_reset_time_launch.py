#!/usr/bin/python2
import rospy
import rostopic
import argparse
import threading

global g_msg
g_msg = None

def msg_callback(msg):
  global g_msg
  g_msg = msg
  #g_msg.header.stamp = rospy.Time.now()
  g_msg.header.stamp = rospy.Time(0) # we need to set this to 0 so the transform doesn't complain about interpolating into the future

def publisher():
  global g_msg
  info_flag = True
  while not rospy.is_shutdown():
    if g_msg is not None:
      if info_flag:
        rospy.loginfo("Publish to topic {} at rate {} Hz".format(out_topic_name, rate_val))
        info_flag = False
      pub.publish(g_msg)
      rate.sleep()

rospy.init_node('message_republish', anonymous=True)
out_topic_name = rospy.get_param("~out_topic_name")
in_topic_name = rospy.get_param("~in_topic_name")
rate_val = rospy.get_param("~rate")

rate = rospy.Rate(float(rate_val))
topic_class, _, _ = rostopic.get_topic_class(in_topic_name)
pub = rospy.Publisher(out_topic_name, topic_class, queue_size=1)
rospy.Subscriber(in_topic_name, topic_class, msg_callback,
    queue_size=1,  buff_size=2**24)
t = threading.Thread(target=publisher)
t.start()
rospy.loginfo("Initialized the republisher with the following parameters: \nout_topic_name  : %s \nin_topic_name   : %s \nrate            : %s", out_topic_name,in_topic_name,rate_val)
rospy.loginfo("Waiting for the first message ...")
rospy.spin()
