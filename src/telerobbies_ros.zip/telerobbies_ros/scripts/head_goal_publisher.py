#!/usr/bin/python2
import rospy
import rostopic
import argparse
import threading
from pr2_controllers_msgs.msg import PointHeadActionGoal, PointHeadGoal
from geometry_msgs.msg import PoseStamped
global g_msg
global msg_recv
msg_recv = False
g_msg = None

def msg_callback(msg):
  global g_msg
  global msg_recv
  g_msg.goal.target.point.x = msg.pose.position.x
  g_msg.goal.target.point.y = msg.pose.position.y
  g_msg.goal.target.point.z = msg.pose.position.z
  g_msg.header.stamp = rospy.Time(0)
  pub.publish(g_msg)
  if(not msg_recv):
    rospy.loginfo("Publishing head tracking")
    msg_recv = True
  rate.sleep()
      

rospy.init_node('head_goal_publisher', anonymous=True)
out_topic_name = rospy.get_param("~out_topic_name")
in_topic_name = rospy.get_param("~in_topic_name")
rate_val = rospy.get_param("~rate")
g_msg = PointHeadActionGoal()
rate = rospy.Rate(rate_val)
g_msg.goal.max_velocity = 1.0;
g_msg.header.frame_id = 'base_link'
g_msg.goal.target.header.frame_id='base_link'
g_msg.goal.pointing_axis.x = 1
g_msg.goal.pointing_axis.y = 0
g_msg.goal.pointing_axis.z = 0
g_msg.goal.pointing_frame = 'head_mount_kinect_rgb_link'
g_msg.goal.max_velocity = 1.0;
topic_class, _, _ = rostopic.get_topic_class(out_topic_name)
sub = rospy.Subscriber(in_topic_name, PoseStamped, msg_callback, queue_size=1)
pub = rospy.Publisher(out_topic_name, topic_class, queue_size=1)

rospy.loginfo("Initialized the head publisher with the following parameters: \nout_topic_name  : %s \nin_topic_name   : %s \nrate            : %s", out_topic_name,in_topic_name,rate_val)
rospy.loginfo("Waiting for the first message ...")
rospy.spin()
